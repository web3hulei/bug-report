/** 
 * @author 胡磊
 * @date 24-9-10
 * @file
 */

#ifndef CUDA_TEST_SRC_MY_TYPE_TRAITS_H
#define CUDA_TEST_SRC_MY_TYPE_TRAITS_H


typedef __int128 int128_t;
typedef unsigned __int128 uint128_t;

template<typename T>
struct my_make_unsigned;

template <>
struct my_make_unsigned<uint8_t> {
    typedef uint8_t type;
};

template <>
struct my_make_unsigned<int8_t> {
    typedef uint8_t type;
};

template <>
struct my_make_unsigned<uint16_t> {
    typedef uint16_t type;
};

template <>
struct my_make_unsigned<int16_t> {
    typedef uint16_t type;
};

template <>
struct my_make_unsigned<uint32_t> {
    typedef uint32_t type;
};

template <>
struct my_make_unsigned<int32_t> {
    typedef uint32_t type;
};

template <>
struct my_make_unsigned<uint64_t> {
    typedef uint64_t type;
};

template <>
struct my_make_unsigned<int64_t> {
    typedef uint64_t type;
};

template <>
struct my_make_unsigned<uint128_t> {
    typedef uint128_t type;
};

template <>
struct my_make_unsigned<int128_t> {
    typedef uint128_t type;
};

template<typename T>
using my_make_unsigned_t = typename my_make_unsigned<T>::type;


template<typename T>
struct my_is_signed;

template<>
struct my_is_signed<int8_t> {
    static constexpr bool value = true;
};

template<>
struct my_is_signed<int16_t> {
    static constexpr bool value = true;
};

template<>
struct my_is_signed<int32_t> {
    static constexpr bool value = true;
};

template<>
struct my_is_signed<int64_t> {
    static constexpr bool value = true;
};

template<>
struct my_is_signed<int128_t> {
    static constexpr bool value = true;
};

template<>
struct my_is_signed<uint8_t> {
    static constexpr bool value = false;
};

template<>
struct my_is_signed<uint16_t> {
    static constexpr bool value = false;
};

template<>
struct my_is_signed<uint32_t> {
    static constexpr bool value = false;
};

template<>
struct my_is_signed<uint64_t> {
    static constexpr bool value = false;
};

template<>
struct my_is_signed<uint128_t> {
    static constexpr bool value = false;
};

template<typename T>
inline constexpr bool my_is_signed_v = my_is_signed<T>::value;

template<typename T>
struct my_is_unsigned;

template<>
struct my_is_unsigned<int8_t> {
    static constexpr bool value = false;
};

template<>
struct my_is_unsigned<int16_t> {
    static constexpr bool value = false;
};

template<>
struct my_is_unsigned<int32_t> {
    static constexpr bool value = false;
};

template<>
struct my_is_unsigned<int64_t> {
    static constexpr bool value = false;
};

template<>
struct my_is_unsigned<int128_t> {
    static constexpr bool value = false;
};

template<>
struct my_is_unsigned<uint8_t> {
    static constexpr bool value = true;
};

template<>
struct my_is_unsigned<uint16_t> {
    static constexpr bool value = true;
};

template<>
struct my_is_unsigned<uint32_t> {
    static constexpr bool value = true;
};

template<>
struct my_is_unsigned<uint64_t> {
    static constexpr bool value = true;
};

template<>
struct my_is_unsigned<uint128_t> {
    static constexpr bool value = true;
};

template<typename T>
inline constexpr bool my_is_unsigned_v = my_is_unsigned<T>::value;
#endif //CUDA_TEST_SRC_MY_TYPE_TRAITS_H
